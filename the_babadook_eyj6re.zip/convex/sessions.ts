import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

// Save a typing session
export const saveSession = mutation({
  args: {
    wpm: v.number(),
    accuracy: v.number(),
    errorCount: v.number(),
    elapsed: v.number(),
    mode: v.string(),
    textId: v.optional(v.id("texts")),
    customText: v.optional(v.string()),
    keystrokes: v.array(v.object({
      char: v.string(),
      correct: v.boolean(),
      timestamp: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const now = Date.now();
    const sessionId = await ctx.db.insert("sessions", {
      userId,
      ...args,
      startedAt: now - args.elapsed,
      endedAt: now,
    });
    // Update leaderboard if WPM is high
    if (args.wpm > 0 && args.accuracy > 0.7) {
      await ctx.db.insert("leaderboard", {
        userId,
        wpm: args.wpm,
        accuracy: args.accuracy,
        mode: args.mode,
        timestamp: now,
      });
    }
    // XP/achievements logic (simplified MVP)
    let ach = await ctx.db
      .query("achievements")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
    if (!ach) {
      await ctx.db.insert("achievements", {
        userId,
        xp: Math.round(args.wpm),
        badges: [],
        streak: 1,
        lastSession: now,
      });
    } else {
      await ctx.db.patch(ach._id, {
        xp: ach.xp + Math.round(args.wpm),
        lastSession: now,
        streak: (ach.lastSession && now - ach.lastSession < 36 * 60 * 60 * 1000) ? ach.streak + 1 : 1,
      });
    }
    return sessionId;
  },
});

// List recent sessions for the logged-in user
export const listSessions = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    return await ctx.db
      .query("sessions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);
  },
});
