import React, { useEffect, useRef, useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { motion, AnimatePresence } from "framer-motion";
import { Id } from "../../convex/_generated/dataModel";

const DEFAULT_TEXT =
  "The Babadook is watching you type. Type fast, type true, and don't let the Babadook catch you!";

function getWords(text: string) {
  return text.split(/\s+/);
}

function TypingTest({
  text = DEFAULT_TEXT,
  mode = "free",
  textId,
  onComplete,
}: {
  text?: string;
  mode?: string;
  textId?: Id<"texts">;
  onComplete?: () => void;
}) {
  const [input, setInput] = useState("");
  const [started, setStarted] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [keystrokes, setKeystrokes] = useState<
    { char: string; correct: boolean; timestamp: number }[]
  >([]);
  const [finished, setFinished] = useState(false);

  const saveSession = useMutation(api.sessions.saveSession);

  const words = getWords(text);
  const chars = text.split("");
  const currentIndex = input.length;
  const correctSoFar =
    text.slice(0, input.length) === input && input.length <= text.length;
  const errorCount = keystrokes.filter((k) => !k.correct).length;
  const correctCount = keystrokes.filter((k) => k.correct).length;
  const accuracy =
    keystrokes.length === 0
      ? 100
      : (correctCount / keystrokes.length) * 100;
  // WPM = (chars / 5) / minutes
  const wpm =
    elapsed > 0
      ? (((input.length / 5) / (elapsed / 60))).toFixed(1)
      : "0.0";

  // Timer
  useEffect(() => {
    if (!started || finished) return;
    const interval = setInterval(() => {
      setElapsed((e) => e + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [started, finished]);

  // Handle input
  function handleKey(e: React.KeyboardEvent<HTMLInputElement>) {
    if (finished) return;
    if (!started) {
      setStarted(true);
      setStartTime(Date.now());
    }
    if (e.key.length === 1) {
      const correct = text[currentIndex] === e.key;
      setInput((inp) => inp + e.key);
      setKeystrokes((ks) => [
        ...ks,
        { char: e.key, correct, timestamp: Date.now() },
      ]);
      if (currentIndex + 1 === text.length) {
        setFinished(true);
        setElapsed(
          Math.round(((Date.now() - (startTime ?? Date.now())) / 1000) * 1)
        );
        setTimeout(() => {
          saveSession({
            wpm: Number(wpm),
            accuracy: accuracy / 100,
            errorCount,
            elapsed: elapsed + 1,
            mode,
            textId: textId ?? undefined,
            customText: !textId ? text : undefined,
            keystrokes,
          });
          onComplete?.();
        }, 500);
      }
    } else if (e.key === "Backspace") {
      setInput((inp) => inp.slice(0, -1));
      setKeystrokes((ks) => ks.slice(0, -1));
    }
  }

  // Blinking cursor
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    inputRef.current?.focus();
  }, [finished]);

  function handleReset() {
    setInput("");
    setStarted(false);
    setStartTime(null);
    setElapsed(0);
    setKeystrokes([]);
    setFinished(false);
  }

  return (
    <div className="w-full max-w-2xl mx-auto p-4 bg-zinc-900/80 rounded-lg shadow-lg text-white">
      <div className="mb-4 flex items-center justify-between">
        <StatsPanel
          wpm={wpm}
          accuracy={accuracy}
          errorCount={errorCount}
          elapsed={elapsed}
        />
        <button
          className="ml-4 px-3 py-1 rounded bg-indigo-700 hover:bg-indigo-800 text-white font-semibold"
          onClick={handleReset}
        >
          Reset
        </button>
      </div>
      <div
        className="relative text-2xl font-mono min-h-[3.5rem] bg-zinc-800 rounded p-4 mb-4"
        tabIndex={0}
        onKeyDown={handleKey}
        ref={inputRef as any}
        aria-label="Typing area"
        role="textbox"
      >
        <TypingText
          text={text}
          input={input}
          currentIndex={currentIndex}
          finished={finished}
        />
      </div>
      <input
        className="opacity-0 absolute pointer-events-none"
        ref={inputRef}
        tabIndex={-1}
        aria-hidden
      />
      <AnimatePresence>
        {finished && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="text-center mt-4"
          >
            <span className="text-green-400 font-bold text-xl">
              Finished! WPM: {wpm}, Accuracy: {accuracy.toFixed(1)}%
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TypingText({
  text,
  input,
  currentIndex,
  finished,
}: {
  text: string;
  input: string;
  currentIndex: number;
  finished: boolean;
}) {
  return (
    <span>
      {text.split("").map((char, i) => {
        let className = "";
        if (i < input.length) {
          className =
            input[i] === char
              ? "text-green-400"
              : "text-red-400 underline decoration-wavy";
        } else if (i === input.length && !finished) {
          className =
            "bg-indigo-400/30 animate-pulse border-b-2 border-indigo-500";
        }
        return (
          <span key={i} className={className}>
            {char}
          </span>
        );
      })}
    </span>
  );
}

function StatsPanel({
  wpm,
  accuracy,
  errorCount,
  elapsed,
}: {
  wpm: string | number;
  accuracy: number;
  errorCount: number;
  elapsed: number;
}) {
  return (
    <div className="flex gap-6 text-lg font-semibold">
      <span>
        <span className="text-indigo-400">WPM:</span> {wpm}
      </span>
      <span>
        <span className="text-indigo-400">Accuracy:</span>{" "}
        {accuracy.toFixed(1)}%
      </span>
      <span>
        <span className="text-indigo-400">Errors:</span> {errorCount}
      </span>
      <span>
        <span className="text-indigo-400">Time:</span> {elapsed}s
      </span>
    </div>
  );
}

export default TypingTest;
