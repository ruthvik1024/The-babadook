import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Stores each typing session with detailed stats
  sessions: defineTable({
    userId: v.id("users"),
    wpm: v.number(),
    accuracy: v.number(),
    errorCount: v.number(),
    elapsed: v.number(),
    mode: v.string(), // "free" | "timed" | "accuracy"
    textId: v.optional(v.id("texts")),
    customText: v.optional(v.string()),
    startedAt: v.number(),
    endedAt: v.number(),
    keystrokes: v.array(v.object({
      char: v.string(),
      correct: v.boolean(),
      timestamp: v.number(),
    })),
  }).index("by_user", ["userId"]),

  // Stores user-saved custom texts
  texts: defineTable({
    userId: v.id("users"),
    title: v.string(),
    content: v.string(),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),

  // Stores achievements and XP
  achievements: defineTable({
    userId: v.id("users"),
    xp: v.number(),
    badges: v.array(v.string()),
    streak: v.number(),
    lastSession: v.optional(v.number()),
  }).index("by_user", ["userId"]),

  // Leaderboard entries (denormalized for fast queries)
  leaderboard: defineTable({
    userId: v.id("users"),
    wpm: v.number(),
    accuracy: v.number(),
    mode: v.string(),
    timestamp: v.number(),
  }).index("by_mode", ["mode"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
